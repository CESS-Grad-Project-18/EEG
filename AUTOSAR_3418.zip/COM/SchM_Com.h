#ifndef SCHM_COM_H_
#define SCHM_COM_H_

/* Scheduled Functions*/
void Com_MainFunctionRx(void); /*SID 0x18*/
void Com_MainFunctionTx(void); /*SID 0x19*/
void Com_MainFunctionRouteSignals(void); /*SID 0x1a*/

#endif
