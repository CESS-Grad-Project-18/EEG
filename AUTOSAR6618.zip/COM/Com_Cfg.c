#include "Com.h"

/* Notifications */
const ComNotificationCalloutType ComNotificationCallouts [] = { NULL };

/* RX Callouts */
const ComRxIPduCalloutType ComRxIPduCallouts[] = { NULL };

/* TX Callouts */
const ComTxIPduCalloutType ComTxIPduCallouts[] = { NULL };